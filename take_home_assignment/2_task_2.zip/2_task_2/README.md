# price_breakout_detection

To run streamlit app on your local computer, please follow these steps on your terminal:
1. Make sure you are in the repository home directory 
`cd price_breakout_detetction`
2. Prepare the environment and install all the dependencies `pip install -r requirements.txt` It is recommended to create a virtual environment. 
3. Trigger the app by `streamlit run app.py`